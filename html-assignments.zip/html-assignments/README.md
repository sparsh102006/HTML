# HTML Assignments

Eighteen HTML assignments, one folder each. Open any `index.html` in a browser.

1. HTML Page Structure and Comments - `assignment-01-page-structure-comments/`
2. Headings, Paragraphs, Formatting and Special Characters - `assignment-02-headings-text-formatting/`
3. Block and Inline Elements - `assignment-03-block-inline-elements/`
4. Semantic and Non-Semantic Elements - `assignment-04-semantic-elements/`
5. Unordered, Ordered and Description Lists - `assignment-05-lists-basic/`
6. Nested and Mixed Lists - `assignment-06-nested-mixed-lists/`
7. Navigation Menu Using Lists - `assignment-07-navigation-menu/`
8. Hyperlinks and Images with Attributes - `assignment-08-links-images/`
9. Quotation and Citation Elements - `assignment-09-quotation-citation/`
10. Multimedia: Image, Video, Audio and YouTube - `assignment-10-multimedia/`
11. Accessibility - `assignment-11-accessibility/`
12. Table with Headers, Caption and Footer - `assignment-12-table-basic/`
13. Rowspan and Colspan (Timetable) - `assignment-13-timetable-rowspan-colspan/`
14. Nested and Responsive Tables - `assignment-14-nested-responsive-tables/`
15. Form: Input Elements, Label and Fieldset - `assignment-15-form-inputs/`
16. Select, Textarea and Buttons - `assignment-16-form-select-textarea-buttons/`
17. Form Attributes and Input Validation - `assignment-17-form-validation/`
18. Mini Project: Accessible Student Admission Page - `assignment-18-mini-project-admission-page/`
